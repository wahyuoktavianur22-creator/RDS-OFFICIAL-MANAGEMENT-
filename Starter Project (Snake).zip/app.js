import { initializeApp } 
from "https://www.gstatic.com/firebasejs/12.16.0/firebase-app.js";


import { 
getAuth,
signInWithEmailAndPassword
}
from "https://www.gstatic.com/firebasejs/12.16.0/firebase-auth.js";



const firebaseConfig = {

apiKey: "AIzaSyBml1NcIeRPM_iaVczp_pvUDZlQcBAfCu0",

authDomain: "rds-official-management.firebaseapp.com",

projectId: "rds-official-management",

storageBucket: "rds-official-management.firebasestorage.app",

messagingSenderId: "237260966181",

appId: "1:237260966181:web:1cbea8b2469df4e88072cc",

measurementId: "G-J8LGHXLJCH"

};



const app = initializeApp(firebaseConfig);


const auth = getAuth(app);



window.login = function(){


let email = document.getElementById("username").value;

let password = document.getElementById("password").value;



signInWithEmailAndPassword(auth,email,password)


.then((user)=>{


alert("Login berhasil RD'S");


window.location.href = "dashboard.html";


})


.catch((error)=>{


alert("Login gagal: " + error.message);


});


}